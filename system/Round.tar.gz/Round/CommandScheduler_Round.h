/*********************************************************************************
*  Copyright (c) 2018-2019, 
*  Reza Mirosanlou
*  University of Waterloo               
*  All rights reserved.
*********************************************************************************/

#ifndef COMMANDSCHEDULER_Round_H
#define COMMANDSCHEDULER_Round_H

#include "../../CommandScheduler.h"

namespace DRAMController
{
	class CommandScheduler_Round: public CommandScheduler
	{
	private:
		vector<pair<BusPacket*, unsigned int>> cmdFIFO;	// FIFO contains ready commands and queue index
		vector<unsigned int> Order;
		int  servicebuffer[15];
		int  blockSWpoint[15];
		// Pending Command indicator based on requestorID
		map<unsigned int, bool> queuePending;
		map<unsigned int, BusPacket*> tempqueue;
		unsigned int counter=0;
		bool roundType = true; // true = Read and false = write
		bool skipCAS = false;
		bool currRound = 0;
		unsigned int countACT=0;
		unsigned int countFAW=0;
		unsigned int countCAS;
		unsigned int lastACT;
		unsigned int lastCAS;
		bool blockACT=false;
		unsigned int tCCD;
		unsigned int tRTR;
		unsigned int tRCD;
		unsigned int tFAW;
		unsigned int tFAWT;
		unsigned int tRRD;
		unsigned int readLatency;
		unsigned int writeLatency;
		unsigned int readToWrite;
		unsigned int writeToRead;
		//unsigned int counterFAW;

	public:
		CommandScheduler_Round(vector<CommandQueue*>& commandQueues, const map<unsigned int, bool>& requestorTable):
			CommandScheduler(commandQueues, requestorTable)
		{}

		~CommandScheduler_Round()
		{
			for(auto it=tempqueue.begin(); it!=tempqueue.end(); it++) {
				//delete it->first;
			}
			cmdFIFO.clear();
			Order.clear();
			for(auto it=0; it<commandQueue.size(); it++) {
				Order.push_back(it);
			}
			//servicebuffer.clear();
			queuePending.clear();
			tempqueue.clear();
			for (int i=0 ; i<16 ; i++) {
				servicebuffer[i]=0;
			}
		}

		BusPacket* commandSchedule()
		{
			tCCD = getTiming("tCCD");
			tRTR = getTiming("tRTR");
			tRRD = getTiming("tRRD");
			tRCD = getTiming("tRCD");
			readLatency = getTiming("tRL");// + getTiming("tBus");
			writeLatency = getTiming("tWL");// + getTiming("tBus");
			readToWrite = getTiming("tRTW") + writeLatency;
			writeToRead = writeLatency + getTiming("tBus") + getTiming("tWTR") + readLatency;
			tFAWT = getTiming("tFAW");
			tFAW = tFAWT- (3*tRRD);
			checkCommand = NULL;
			//checkCommand1 = NULL;
			for(unsigned int index = 0; index < commandQueue.size(); index++)
			{
				// PerRequestor is enabled and there is some requestors in this memory level
				if(commandQueue[index]->isPerRequestor()) 
				{
					if(commandQueue[index]->getRequestorIndex() > 0) // there is more than 0 requestor in the design
					{
						for(unsigned int num=0; num<commandQueue[index]->getRequestorIndex(); num++) // for all requestors from "num"
						{
							if(commandQueue[index]->getRequestorSize(num) > 0 ) //return the buffer size of the requestor
							{
								checkCommand = commandQueue[index]->getRequestorCommand(num);
								if(queuePending.find(checkCommand->requestorID) == queuePending.end()) {
									queuePending[checkCommand->requestorID] = false;
								}
								if(queuePending[checkCommand->requestorID] == false && isReady(checkCommand, index)) { //checks in terms of intra constraint
									if(requestorCriticalTable.at(checkCommand->requestorID) == true) {
										tempqueue[checkCommand->requestorID]= checkCommand;
										//cmdFIFO.push_back(std::make_pair(checkCommand,index));
									}
									else {
										tempqueue[checkCommand->requestorID]= checkCommand;
										//cmdFIFO.push_back(std::make_pair(checkCommand,index));
									}
									
									queuePending[checkCommand->requestorID] = true;
								}
								checkCommand = NULL;
							}
						}
					}	
				}
				// single memory level queue with hrt and srt
				else
				{
					if(commandQueue[index]->getSize(true) > 0 && queuePending[index] == false)
					{
						checkCommand = commandQueue[index]->getCommand(true);
					}
					if(checkCommand == NULL && commandQueue[index]->getSize(false) > 0)
					{
						checkCommand = commandQueue[index]->getCommand(false);
					}
					if(checkCommand != NULL) {
						if(isReady(checkCommand, index)) {
							tempqueue[checkCommand->requestorID]= checkCommand; // cmdFIFO.push_back(std::make_pair(checkCommand,index));
							queuePending[index] = true;
						}
						checkCommand = NULL;
					}
				}
			}
			scheduledCommand = NULL;
			// Schedule the commands based on the rules and round
			//Switch and Reset rules to be here
			//Basically the switch rule only works when we reach the counter and then check whether we have ACT/CAS from the other type or not
			if(counter == lastACT)
			{
				blockACT=true;	
			}
			if (counter == lastCAS)
			{
				for(unsigned int index = 0; index < commandQueue.size(); index++)  
				{
					checkCommand = tempqueue[index];
					if(roundType==0)
					{
						if (checkCommand->busPacketType == ACT_W) 
						{
							if(isIssuable(checkCommand))
							{	
							roundType = !roundType;
							counter = 0;
							}
						}
					}
					else if (roundType = 1 )
					{
						if (checkCommand->busPacketType == ACT_R)
						{	
							if(isIssuable(checkCommand))
							{
							roundType = !roundType;
							counter = 0;
							}
						}
					}
					else if (roundType = 1 )
					{
						if (checkCommand->busPacketType == RD)
						{	
							if(isIssuable(checkCommand))
							{
							roundType = !roundType;
							counter = 0;
							}
						}
					}
					else if (roundType = 0 )
					{
						if (checkCommand->busPacketType == WR)
						{	
							if(isIssuable(checkCommand))
							{
							roundType = !roundType;
							counter = 0;
							}
						}
					}
					else if (roundType = 1 )
					{
						if (checkCommand->busPacketType == RDA)
						{	
							if(isIssuable(checkCommand))
							{
							roundType = !roundType;
							counter = 0;
							}
						}
					}
					else if (roundType = 0 )
					{
						if (checkCommand->busPacketType == WRA)
						{	
							if(isIssuable(checkCommand))
							{
							roundType = !roundType;
							counter = 0;
							}
						}
					}
					else
					{ 
						for(uint64_t i=0 ; i<commandQueue.size(); i++)
						{
							servicebuffer[i]==0;
							counter = 0;
						}
					}	
				}	
			}

			//now we determined that the round is switched or has been reset!
			//What we are going to do is actually schedule the requests based on the round, serviced or not and RR order
			//schedule the CAS first
			//Arbitter for the CAS > ACT > PRE
			//Round-Robin ACT arbitration

			for(unsigned int index = 0; index < tempqueue.size(); index++)
			{
				checkCommand = tempqueue[index];
				if(blockSWpoint[index]=0)
				{
					if (roundType==0)
					{
						if 	(checkCommand->busPacketType==ACT_R)
						{
							if (servicebuffer[index]==0)
							{
								countACT++;
								if(countACT==5)
								{
									countFAW++;
									countACT=0;
								}
								blockSWpoint[index]=1;
							}
						}
						else if(checkCommand->busPacketType==RD)
						{
							if (servicebuffer[index]==0)
							{
								countCAS++;
								blockSWpoint[index]=1;
							}
						}
						else if(checkCommand->busPacketType==RDA)
						{
							if (servicebuffer[index]==0)
							{
								countCAS++;
								blockSWpoint[index]=1;
							}
						}
					}
					else if (roundType==1)
					{
						if 	(checkCommand->busPacketType==ACT_W)
						{
							if (servicebuffer[index]==0)
							{
								countACT++;
								if(countACT==5)
								{
									countFAW++;
									countACT=0;
								}
								blockSWpoint[index]=1;
							}
						}
						else if(checkCommand->busPacketType==WR)
						{
							if (servicebuffer[index]==0)
							{
								countCAS++;
								blockSWpoint[index]=1;
							}
						}
						else if(checkCommand->busPacketType==WRA)
						{
							if (servicebuffer[index]==0)
							{
								countCAS++;
								blockSWpoint[index]=1;
							}
						}
					}
				}	
			}

			lastACT = (countACT*tRRD) + (countFAW*tFAW) - tRCD;
			lastCAS = (countCAS*tCCD);

			if(!tempqueue.empty())
			{
				for(unsigned int index = 0; index < tempqueue.size(); index++)
				{
					int RR = Order.at(index);
					checkCommand = tempqueue[RR];
					if (checkCommand->busPacketType == RD)
					{
						if (roundType==0)
						{
							if(servicebuffer[index]==0)
							{
								cmdFIFO.push_back(std::make_pair(checkCommand,index));
								tempqueue.erase(RR);
								blockSWpoint[RR]=0;
								Order.pop_back;
								Order.push_back(RR);
								servicebuffer[index]==1;
							}
						}
					checkCommand = NULL;
					}
					else if (checkCommand->busPacketType == RDA)
					{
						if (roundType==0)
						{
							if(servicebuffer[index]==0)
							{
								cmdFIFO.push_back(std::make_pair(checkCommand,index));
								tempqueue.erase(RR);
								blockSWpoint[RR]=0;
								Order.pop_back;
								Order.push_back(RR);
								servicebuffer[index]==1;	
							}
						}
					checkCommand = NULL;
					}
					else if (checkCommand->busPacketType == WR)
					{
						if (roundType==1)
						{
							if(servicebuffer[index]==0)
							{
								cmdFIFO.push_back(std::make_pair(checkCommand,index));
								tempqueue.erase(RR);
								blockSWpoint[RR]=0;
								Order.pop_back;
								Order.push_back(RR);
								servicebuffer[index]==1;	
							}
						}
					checkCommand = NULL;
					}
					else if (checkCommand->busPacketType == WRA)
					{
						if (roundType==1)
						{
							if(servicebuffer[index]==0)
							{
								cmdFIFO.push_back(std::make_pair(checkCommand,index));
								tempqueue.erase(RR);
								blockSWpoint[RR]=0;
								Order.pop_back;
								Order.push_back(RR);
								servicebuffer[index]==1;	
							}
						}
					checkCommand = NULL;
					}
					else if (checkCommand->busPacketType == ACT_R){
						if (!blockACT){
							if (roundType==0){
								if(servicebuffer[index]==0){
									cmdFIFO.push_back(std::make_pair(checkCommand,index));
									tempqueue.erase(RR);	
									blockSWpoint[RR]=0;																
								}
							}
						checkCommand = NULL;
						}
					}	
					else if (checkCommand->busPacketType == ACT_W){
						if(!blockACT){
							if (roundType==1){
								if(servicebuffer[index]==0){
									cmdFIFO.push_back(std::make_pair(checkCommand,index));
									tempqueue.erase(RR);
									blockSWpoint[RR]=0;	
								}
							}
						}	
						checkCommand = NULL;
					}
					else if (checkCommand->busPacketType == PRE){
						cmdFIFO.push_back(std::make_pair(checkCommand,index));
						tempqueue.erase(RR);
						blockSWpoint[RR]=0;	
					}
					//if there is nothing ready in the Q, we can simply issue the opportunistically
					else if (checkCommand->busPacketType == RD){
						if (roundType==0){
							if(servicebuffer[index]==1){
								cmdFIFO.push_back(std::make_pair(checkCommand,index));
								tempqueue.erase(RR);
								blockSWpoint[RR]=0;
								Order.pop_back;
								Order.push_back(RR);
								lastCAS = lastCAS + tCCD;								
							}
						}
					checkCommand = NULL;
					}
					else if (checkCommand->busPacketType == RDA){
						if (roundType==0){
							if(servicebuffer[index]==1){
								cmdFIFO.push_back(std::make_pair(checkCommand,index));
								tempqueue.erase(RR);
								blockSWpoint[RR]=0;
								Order.pop_back;
								Order.push_back(RR);
								lastCAS = lastCAS + tCCD;									
							}
						}
					checkCommand = NULL;
					}
					else if (checkCommand->busPacketType == WR){
						if (roundType==1){
							if(servicebuffer[index]==1){
								cmdFIFO.push_back(std::make_pair(checkCommand,index));
								tempqueue.erase(RR);
								blockSWpoint[RR]=0;
								Order.pop_back;
								Order.push_back(RR);
								lastCAS = lastCAS + tCCD;									
							}
						}
					checkCommand = NULL;
					}
					else if (checkCommand->busPacketType == WRA){
						if (roundType==1){
							if(servicebuffer[index]==1){
								cmdFIFO.push_back(std::make_pair(checkCommand,index));
								tempqueue.erase(RR);
								tempqueue.erase(RR);
								Order.pop_back;
								Order.push_back(RR);
								lastCAS = lastCAS + tCCD;									
							}
						}
					checkCommand = NULL;
					}
				}
			}
			//schedule the Command register in the same order that it was scheduled!
			if(cmdFIFO.size() > 0) {
				checkCommand = cmdFIFO.begin;
				if(isIssuable(checkCommand)) {
					scheduledCommand = checkCommand;
					sendCommand(scheduledCommand, cmdFIFO.begin.second);
					cmdFIFO.erase(cmdFIFO.begin());
					counter++;
					return scheduledCommand;
				}
			}
		counter++;
		return NULL;
		}
	};
}
#endif


/*

if (continiue == true){
			for(unsigned int index = 0; index < commandQueue.size(); index++)	{
				checkCommand = tempqueue[index];
				if (checkCommand->busPacketType == ACT_R){
					if(roundType=1){
						if(isIssuable(checkCommand)){
						roundType = !roundType;
						skipCAS = true;
						}
					}
				}
				else if (checkCommand->busPacketType == ACT_W){
					if(roundType=0){
						if(isIssuable(checkCommand)){
						roundType = !roundType;
						skipCAS = true;
						}
					}
				}
				else if (checkCommand->busPacketType == RD){
					if(roundType=1){
						if(isIssuable(checkCommand)){
						roundType = !roundType;
						skipCAS = true;
						}
					}
				}
				else if (checkCommand->busPacketType == WR){
					if(roundType=0){
						if(isIssuable(checkCommand)){
						roundType = !roundType;
						skipCAS = true;
						}
					}
				}
				else if (checkCommand->busPacketType == RDA){
					if(roundType=1){
						if(isIssuable(checkCommand)){
						roundType = !roundType;
						skipCAS = true;
						}
					}
				}
				else if (checkCommand->busPacketType == WRA){
					if(roundType=0){
						if(isIssuable(checkCommand)){
						roundType = !roundType;
						skipCAS = true;
						}
					}
				}
				else{ 
					for(uint64_t i=0 ; i<commandQueue.size(); i++)
					servicebuffer[i]==0;
				}				
			}
		}
			

		/*if (skipCAS==false){
			for(unsigned int index = 0; index < commandQueue.size(); index++)  {
				checkCommand = tempqueue[index];
				checkCommand1 = commandQueue[index]->getCommand(true);
				if ((checkCommand->busPacketType == ACT || checkCommand->busPacketType == WR || checkCommand->busPacketType == RD) && roundType == checkCommand1->busPacketType && servicebuffer[index]==0)	{
					con = false;
				}
			}
			if (con == true)	{
				for(unsigned int index = 0; index < commandQueue.size(); index++)	{
					checkCommand = tempqueue[index];
					checkCommand1 = commandQueue[index]->getCommand(true);
					if ((checkCommand->busPacketType == ACT || checkCommand->busPacketType == WR || checkCommand->busPacketType == RD) && roundType != checkCommand1->busPacketType)	{
						if(isIssuable(checkCommand)){
							roundType = !roundType;
						}	
					}
					for(uint64_t i=0 ; i<commandQueue.size(); i++)
							servicebuffer[i]==0;
				}
			}
		}
		*/
/*
if(scheduledCommand == NULL && !tempqueue.empty()) {
			for(unsigned int index = 0; index < tempqueue.size(); index++) {
				int RR = Order.pop();
				checkCommand = tempqueue[RR];
				if (checkCommand->busPacketType == ACT){
					if(isIssuable(checkCommand)) {
						scheduledCommand = checkCommand;
						//registerIndex = index;
						break;
					}
					checkCommand = NULL;
				}

			}

		}
			
		if(scheduledCommand == NULL && !tempqueue.empty()) {
				for(unsigned int index = 0; index < tempqueue.size(); index++) {
					int RR = Order.pop();
				checkCommand = tempqueue[RR];
				if (checkCommand->busPacketType == CAS){
					if(isIssuable(checkCommand)) {
						scheduledCommand = checkCommand;
						//registerIndex = index;
						break;
					}
					checkCommand = NULL;
				}

			}

		}

		if(scheduledCommand == NULL && !tempqueue.empty()) {
				for(unsigned int index = 0; index < tempqueue.size(); index++) {
					int RR = Order.pop();
				checkCommand = tempqueue[RR];
				if (checkCommand->busPacketType == PRE){
					if(isIssuable(checkCommand)) {
						scheduledCommand = checkCommand;
						//registerIndex = index;
						break;
					}
					checkCommand = NULL;
				}

			}

		}
		*/